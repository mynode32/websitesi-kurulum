# Teslim kontrolü

## Demo teslimi

- [ ] Demo ibareleri ve temsili görsel açıklamaları görünür.
- [ ] Gerçekmiş gibi sunulan firma/ilan/referans bilgisi yok.
- [ ] Kapsamdaki sayfa ve akışlar çalışıyor.
- [ ] Mobil, masaüstü ve azaltılmış hareket kontrolleri tamam.
- [ ] Önce/sonra kanıtları ve değişiklik özeti mevcut.
- [ ] Kaynak kodlar, önizleme ve yerel çalıştırma bilgisi teslim edildi.
- [ ] İçeriğin nereden ve nasıl değiştirileceği açık.
- [ ] Form/panel/harita gibi kapsam kararları yazılı.
- [ ] Müşteri bekleyen alanlar tek listede.
- [ ] Demo ortamı arama motorlarına kapalı.

## Gerçek yayından önce

- [ ] Müşteri firma, iletişim ve ilan bilgilerini doğruladı.
- [ ] Gerçek görsellerin kullanım hakları ve içerik onayı alındı.
- [ ] Yayınlanacak tüm demo kayıtlar kaldırıldı veya açıkça ayrıldı.
- [ ] Gizlilik/aydınlatma içerikleri gerçek veri akışına uygun olarak sağlandı ve onaylandı.
- [ ] Form varsa gerçek alıcıya teslim ve hata davranışı kontrol edildi.
- [ ] Alan adı, HTTPS ve üretim ayarları doğrulandı.
- [ ] Üretimde başlık, açıklama, paylaşım görselleri, canonical ve site haritası doğru.
- [ ] İndeksleme kararı gerçek yayın amacıyla uyumlu; demo noindex ayarı yanlışlıkla taşınmadı.
- [ ] Barındırma, alan adı, e-posta ve diğer hesapların sahipliği müşteride.
- [ ] Ücretler, yenilemeler, yedekleme ve bakım sorumlusu yazılı.
- [ ] Kullanıcı yayın yetkisi verdi; canlı adreste temel akış kontrol edildi.

İşaretlenmeyen maddeler açıklanır. “Demo tamam” ile “gerçek yayına hazır” aynı sonuç değildir. Dış hizmet veya müşteri bilgisi eksikse teslim raporunda açıkça belirtilir.
