# Kullanım

Bu klasör bir web sitesi çalışma paketidir; web sitesi kaynak kodu değildir. Mevcut sitenin kodlarına erişim sağlanınca uygulanır.

1. AGENTS.md dosyasını projenin ana klasörüne yerleştir. Mevcut AGENTS.md varsa üzerine yazmadan kuralları birleştir.
2. Diğer dosya ve klasörleri de aynı ana klasöre kopyala. Çakışan dosya adlarını önce kontrol et.
3. Codex'e aşağıdaki başlangıç talimatını gönder.

## Kopyalanacak başlangıç talimatı

Bu projede AGENTS.md kurallarını uygula. Önce DURUM.md ve yalnızca aktif aşamanın belgesini oku. Şu an gerçek müşteri verimiz yok; demo içerikleri açıkça etiketle. İlk aşamada mevcut siteyi ve kaynak kodlarını incele, başlangıç ekran görüntülerini al ve uygulanabilir planı çıkar. Bu aşamada uygulama kodunu değiştirme. Sonraki aşamaya geçmeden bulgularını ve planını bana sun. Her uygulama aşamasında önce/sonra farkını tarayıcıda doğrula, kanıtlarını kaydet ve ilerleme dosyasını güncelle. Tüm Markdown belgelerini tekrar tekrar okuma.

## Sonraki mesaj örnekleri

- “Plan uygun, 02. aşamaya geç.”
- “Sadece mobil menüyü düzelt; diğer bölümleri değiştirme.”
- “03 ve 04. aşamaları sırayla tamamla, kontrollerini ayrı kaydet.”
- “Kaldığın yerden DURUM.md üzerinden devam et.”

## Dosya okuma düzeni

Her başlangıç: kısa AGENTS.md → DURUM.md → aktif aşama → ilgili kod.
Animasyon: ek olarak ANIMASYONLAR.md.
Müşteri verisi: ek olarak MUSTERI-BILGILERI.md.
Teslim: ek olarak TESLIM.md.

AGENTS.md, Codex tarafından otomatik yüklenebilen proje talimatıdır. Bu paket gereksiz belge okumalarını azaltan bir çalışma kuralı sunar; sıfır tekrar okuma veya sabit token tüketimi garantisi vermez. Üst klasör ve alt klasör talimatları da uygulanabilir. Yeni konuşma ve bağlam kaybında kısa durum kaydı tekrar okunmalıdır.

## Kaynaklar

- Codex proje talimatları: https://learn.chatgpt.com/docs/agent-configuration/agents-md
- Hareket azaltma: https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion
- Görünürlük tetikleme: https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API
- React kullanılıyorsa Motion hareket azaltma: https://motion.dev/docs/react-use-reduced-motion

Süreler ve efekt seçimleri bu proje için önerilen tasarım kararlarıdır; kaynakların zorunlu kıldığı değerler değildir.
