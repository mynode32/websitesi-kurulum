# Web sitesi çalışma kuralları

- Kullanıcının güncel isteği önceliklidir. Gerçek veri gelene kadar açıkça etiketlenmiş demo verileri kullan; firma, referans veya ilan bilgisi uydurma.
- Başlangıçta yalnızca `DURUM.md` ve orada belirtilen aktif aşama dosyasını oku. İlgili kaynak kodlarını incele. Tüm Markdown dosyalarını topluca okuma.
- Aynı konuşmada değişmemiş belgeleri tekrar okuma. Yeni konuşmada veya bağlam kaybında DURUM.md üzerinden devam et. İlgili alt klasör talimatları varsa uygula.
- Varsayılan çalışma: bir istekte bir aşama. Aktif aşamayı uygula, kontrol et, kaydet ve kullanıcıya sun. Sonraki aşamaya kullanıcı devam dediğinde geç. Kullanıcı birden çok aşamayı açıkça yetkilendirirse sırayla tamamla.
- Küçük düzeltmeler için tüm süreci baştan başlatma; ilgili aşamada düzeltip etkilediği akışları kontrol et.
- Düzenlemeden önce mevcut kullanıcı değişikliklerini kontrol et; üzerine yazma. Sadece görevle ilgili dosyaları değiştir.
- Görünür değişiklikten önce ve sonra aynı adres, ekran boyutu, veri ve arayüz durumunda ekran görüntüsü al. Kod değişmiş olmasını görünür sonuç kanıtı sayma.
- Değişiklikten sonra tarayıcıda sonucu aç; hedef davranışı ve etkilenen yakın akışları kontrol et. Kontrol edemediğin şeyi açıkça belirt.
- Animasyon işi sırasında yalnızca `ANIMASYONLAR.md` ek olarak okunur. Teslim sırasında `TESLIM.md`; müşteri içeriği gerektiğinde `MUSTERI-BILGILERI.md` okunur.
- Her aşama sonunda DURUM.md'yi güncelle, `kayitlar/DEGISIKLIKLER.md` dosyasına kısa kayıt ekle. Eski kayıtların tümünü okumak yerine son ilgili kaydı incele.
- Sonuç mesajı: ne değişti, önce/sonra farkı, hangi kontroller yapıldı, kalan engel ve sonraki aşama. Kanıt dosyalarını bağla.
- Çalışmayan özelliğe başarı mesajı verme. Demo onayı ile gerçek yayın hazır olma durumunu ayrı tut. Yayınlama ve ücretli hizmet kapsamı kullanıcı isteğiyle belirlenir.
