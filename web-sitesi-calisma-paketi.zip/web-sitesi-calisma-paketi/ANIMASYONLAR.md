# Toprak Ehli animasyon planı

Hedef: Sakin, güven veren, doğal hareket. Bunlar önerilen proje değerleridir. Önce mevcut teknoloji ve efektleri incele.

## Uygulanacak hareketler

| Alan | Davranış | Süre ve sınır |
|---|---|---|
| İlk ekran başlığı | Bir defa hafif yükselme ve belirginleşme | 450 ms; en fazla 12 px; tüm giriş dizisi 700 ms içinde tamamlanır |
| İlk ekran butonları | Başlıktan kısa süre sonra giriş | 350 ms; en fazla 80 ms gecikme; tıklanabilirlik bekletilmez |
| Bölüm başlıkları | İlk görünür olduğunda tek seferlik giriş | 400 ms; 12 px; her kaydırmada tekrar etmez |
| Portföy kartları | İlk gösterimde kısa sıralı giriş | 300 ms; kartlar arası 50 ms; toplam gecikme en fazla 150 ms |
| Kart üzerine gelme | Kart en fazla 3 px yükselir, gölge yumuşar | 180 ms; yalnızca uygun fare/hover cihazlarında |
| Kart görseli | Kart üzerine gelince küçük yakınlaşma | 250 ms; ölçek en fazla 1.025; kapsayıcı taşmayı keser |
| Buton | Renk geçişi; basarken küçük geri bildirim | 150 ms; basma ölçeği en az 0.98; odak işareti korunur |
| Filtre sonucu | Sonuç güncellemesine kısa belirginleşme | 150 ms; tüm listeyi her tuşta yeniden oynatma; klavye odağını taşıma |
| Karşılaştırma seçimi | Seçili sınır/rengin geçişi ve kısa durum bildirimi | 150 ms; sayfa otomatik aşağı atlamaz |
| Detay penceresi varsa | Karartma ve panelin hafif girişi/çıkışı | 180–220 ms; en fazla 8 px; odak ve Escape davranışını koru |
| SSS | Kontrollü açılma/kapanma | 180–220 ms; içerik boyuna uyumlu; metin kesilmez |
| Mobil menü | Kısa açılma/kapanma | 180 ms; görünmez menü öğeleri odak almaz |
| WhatsApp | Sabit ve sakin görünüm | Sürekli nabız, zıplama veya sallanma yok |

## Uygulama tercihi

- Basit etkileşimlerde mevcut CSS transition/animation yeterliyse yeni bağımlılık ekleme.
- Görünüme girişleri mevcut sistemle veya IntersectionObserver ile tek sefer tetikle; gözlem bitince temizle.
- React projesinde Motion zaten varsa onu kullan. Eklenmesi gerekiyorsa nedenini ve maliyetini belirt; sadece birkaç fade için ekleme.
- Aynı öğede CSS, Motion ve başka bir animasyon motorunu üst üste çalıştırma.
- Öncelikle transform ve opacity kullan. Büyük yüzeylerde yoğun blur ve sürekli gölge animasyonundan kaçın. Gerekçesiz `transition: all` kullanma.
- Akordeonda doğal içerik yüksekliğini yönet; sabit max-height nedeniyle uzun metni kesme.
- Parallax, özel imleç, scroll ele geçirme, otomatik kayan metin, sürekli zoom ve açılışta siteyi bekleten yükleme gösterisi bu kapsamda yok.

## Erişilebilirlik ve hata durumları

- `prefers-reduced-motion: reduce` durumunda giriş kaydırma/ölçek ve smooth scroll kaldırılır. İçerik doğrudan görünür; durum değişikliği renk ve metinle anlaşılır.
- React Motion kullanılıyorsa `useReducedMotion` veya uygun genel yapılandırma ile tercihi uygula; CSS efektleri ayrıca kontrol et.
- JavaScript veya gözlemci çalışmazsa içerik opacity:0 durumunda kalmamalı. Başlangıç görünürlüğü güvenli olsun.
- Animasyon bitmesini bekleyen iş mantığı kurma; sıfır süre ve azaltılmış hareket durumunda akış çalışmalı.
- Hızlı aç/kapa, tekrar filtreleme ve sayfadan ayrılmada efektler takılmamalı; observer/listener temizliği yapılmalı.

## Kanıt

Her efekt ailesi için normal hareket, azaltılmış hareket ve mobil etkileşimi kontrol et. Başlangıç/orta/bitiş görüntülerini veya kısa videoyu `kayitlar/kanitlar/04/` altında tut. Gerçekten izleyemediğin hareketi onaylandı diye raporlama.

## Araştırma kaynakları

- https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API
- https://developer.mozilla.org/en-US/docs/Web/CSS/Reference/At-rules/@media/prefers-reduced-motion
- https://motion.dev/docs/react-use-reduced-motion
