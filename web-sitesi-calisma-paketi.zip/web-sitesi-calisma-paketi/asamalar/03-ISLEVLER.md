# 03 — Sayfalar ve işleyiş

- Demo verisini sunum kodundan ayır; kalıcı ilan kimliği ve bilinmeyen alanlar için ortak davranış kullan.
- Kabul edilen kapsamda portföy listesi, ayrı detay adresi, galeri, filtre, sıralama, sıfırlama, boş sonuç ve karşılaştırmayı tamamla.
- Geçersiz ilan adresi ve doğrudan açılan detay bağlantısını kontrol et.
- İlan bazlı iletişim mesajına ilan kimliğini ekle. Harita bilgisi yoksa hatalı pin veya boş harita gösterme.
- Gerçek iletişim bilgileri doğrulanmadıysa demo ortamında açıkça belirt; rastgele numaraya yönlendirme yapma.
- Form/panel yalnızca kapsamda varsa oluştur. Form için gerçek teslim kanalı ve hata durumunu; panel için yetkilendirmeyi doğrula. Görsel olarak çalışan sahte akış teslim etme.
- Eksik fotoğraf, uzun başlık, boş veri, tek ilan ve çok sonuç durumlarını kontrol et.
- Önce/sonra kanıtlarını aynı demo veri kümesiyle al. Yerel demo değişikliklerini gerçek müşteri kaydı gibi sunma.

Çıkış koşulu: Kapsamdaki akışlar uçtan uca çalışır; eksik dış hizmetler açıkça bekleyen olarak kaydedilir; tasarım aşamasındaki düzen bozulmaz.
