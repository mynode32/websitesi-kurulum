# 01 — İnceleme ve plan

Amaç: Mevcut yapıyı anlamak ve hangi sorunun nasıl çözüleceğini somutlaştırmak.

1. Proje talimatlarını, çalışma ağacındaki değişiklikleri, paket dosyasını ve mevcut çalıştırma komutlarını incele. Teknolojiyi tahmin etme.
2. Siteyi yerelde aç. Kaynak kodu yoksa bunu belirt; yalnızca canlı sayfadan kod düzeltmesi yapmış gibi davranma.
3. Ana ekran, portföy, detay, karşılaştırma ve iletişimi 390×844 ve 1440×900 boyutlarında incele. Kanıtları `kayitlar/kanitlar/01/` altında tut.
4. Mevcut işlevleri kaydet; zaten çalışan özelliği eksik diye listeleme. Hataları yeniden üretme adımlarıyla yaz.
5. Tasarım dilini, içerik eksiklerini, mobil sorunları, bağımlılıkları ve yayın ihtiyaçlarını belirle.
6. Sonraki aşamalar için kısa görev listesi, kapsam dışı işler ve müşteri bekleyen alanları yaz. Panel veya form gibi kapsamı büyüten işleri varsayma.

Çıkış koşulu: Başlangıç kanıtları ve öncelikli plan hazır, kullanıcıya sunulmuş. Bu aşamada uygulama kodunu değiştirme. Gerçek müşteri verisi yokluğu tasarım ve demo işlevlerini durdurmaz.
