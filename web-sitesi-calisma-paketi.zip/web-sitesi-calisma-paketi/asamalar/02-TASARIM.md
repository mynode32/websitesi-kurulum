# 02 — Yerleşim ve görsel düzen

Girdi: 01. aşamada kabul edilen plan.

- Mevcut yeşil/krem renk yaklaşımını ve marka karakterini koru; yeni tasarım istenmedikçe komple yenileme yapma.
- Renk, yazı boyutu, aralık, köşe ve buton stillerini ortak tanımlarda topla.
- Ana mesajın altına sunulan hizmeti ve bölgeyi anlatan anlaşılır metin ekle. Doğrulanmamış şirket iddiası ekleme.
- Mobil menü, yazı okunurluğu, dokunma alanları, bölüm aralıkları ve sabit WhatsApp düğmesinin konumunu düzenle.
- 390×844 ve 1440×900 görünümlerini önce/sonra karşılaştır. 320 piksel genişlikte de sayfanın yatay taşmadığını kontrol et. Karşılaştırma tablosunun kendi iç kaydırması kabul edilebilir.
- Bu aşamada animasyon ekleme; önce sabit yerleşimi tamamla. Gerçek içerik uzunluğuna yakın demo metin kullan.

Çıkış koşulu: Ana sayfa ve ortak bileşenler okunaklı, tutarlı, mobilde kullanılabilir; menü ve bağlantılar çalışır; görsel farklar kanıtlanmış.
