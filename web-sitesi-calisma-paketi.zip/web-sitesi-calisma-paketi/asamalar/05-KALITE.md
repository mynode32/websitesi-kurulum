# 05 — Kalite kontrolü

- Mevcut build, lint ve anlamlı testleri çalıştır. Komutları proje tanımından al; olmayan testleri geçmiş gibi raporlama.
- 390×844, 768×1024 ve 1440×900 boyutlarında temel akışları kontrol et; 320 piksel genişlikte taşma kontrolü yap.
- Klavye ile menü, filtre, karşılaştırma, detay ve iletişime eriş. Modal varsa Escape ile kapanma ve odağın tetikleyiciye dönüşünü kontrol et.
- Görsel alternatifleri, form etiketleri, odak görünürlüğü, renk okunurluğu ve azaltılmış hareketi kontrol et.
- Yerel sayfada görsel yüklenmesi, konsol hataları ve gereksiz büyük dosyaları incele. Performans ölçüyorsan URL, koşul ve tarihi yaz; puan uydurma.
- Demo noindex ayarını koru. Gerçek alan adı belli olmadan yanlış canonical veya site haritası yayınlama. Demo ilanları gerçek satış verisi gibi yapılandırılmış veriye ekleme.
- Önceki aşamaların ekranlarıyla karşılaştır; beklenmedik değişimi gider. Kullanıcının sonradan yaptığı düzenlemeleri geri alma.

Çıkış koşulu: Kritik hata yok; kontrol kanıtları var; yapılamayan kontroller ve müşteri bekleyen işler açık.
