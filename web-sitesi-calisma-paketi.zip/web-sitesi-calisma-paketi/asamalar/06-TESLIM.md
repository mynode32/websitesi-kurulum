# 06 — Teslim ve yayın hazırlığı

Bu aşamada TESLIM.md dosyasını oku. Müşteri içeriği için gerekiyorsa MUSTERI-BILGILERI.md dosyasını aç.

- Demo teslimi ile gerçek yayına hazır olma durumunu ayrı değerlendir.
- Kaynak kodu, önizleme, içerik değiştirme yöntemi ve kapsamda kalan işleri hazırla.
- Gerçek veri yoksa demo sürüm teslim edilebilir; “gerçek yayına hazır” diye işaretleme.
- Yayın yetkisi verilmişse alan adı, HTTPS, ortam değişkenleri ve bağlantıları kontrol ederek yayınla; canlı adreste kısa akış kontrolü yap.
- Yayın yetkisi yoksa somut önizlemeyi ve yayın planını sun. Hesap şifrelerini belgeye koyma; erişimi davet ile sağla.

Çıkış koşulu: Teslim türü, tamamlananlar, bekleyenler, hesap sahipliği ve bakım sorumluluğu belgelenmiş.
