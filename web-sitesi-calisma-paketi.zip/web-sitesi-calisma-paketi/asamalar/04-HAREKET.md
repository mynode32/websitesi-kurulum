# 04 — Animasyonlar

Yalnızca bu aşamada ANIMASYONLAR.md dosyasını aç.

1. Mevcut animasyonları tespit et; aynı öğeye ikinci animasyon sistemi bağlama.
2. Önce buton/kart geri bildirimi, sonra bölüm girişleri, ardından pencere/akordeon geçişlerini uygula.
3. Hareketi önce bir örnek bileşende doğrula, sonra ortak bileşenlere yay.
4. Normal hareket ve azaltılmış hareket modlarında kontrol et. Mobilde dokunma, kaydırma, odak ve tıklama çalışsın.
5. Açılış, orta durum ve bitişi kısa video veya sıralı görüntülerle kaydet. Tek son ekran görüntüsü hareketin doğru olduğunu kanıtlamaz.

Çıkış koşulu: Animasyonlar içerik erişimini geciktirmez, sayfa zıplamaz, azaltılmış hareket tercihi uygulanır, filtre ve karşılaştırma çalışır.
