# Değişiklik kaydı

Henüz uygulama değişikliği yapılmadı. Her aşamada aşağıdaki kısa şablonu doldur; büyük günlükler veya komut çıktıları ekleme.

## Tarih — Aşama — Kısa açıklama
- İstek / hedef:
- Önceki davranış:
- Yeni davranış:
- Değişen dosyalar:
- Önce / sonra kanıtları ve ekran ölçüsü:
- Çalıştırılan kontrol ve sonuç:
- Beklenmedik değişiklik / düzeltme:
- Kontrol edilemeyen alan:
- Müşteri veya kullanıcı bekleyen konu:
- Sonraki adım:

Yeni kaydı en üste ekle. Bir hata yeniden açılırsa ilgili eski kayda bağlantı ver. Tüm geçmişi her görevde tekrar okuma.
