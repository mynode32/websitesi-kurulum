# Müşteriden istenecekler

Bu dosyayı yalnızca içerik toplama veya gerçek yayın hazırlığında oku. Bilinmeyenleri tahmin etme. Eksikler demo geliştirmesini engellemez; gerçek yayını etkileyenleri işaretle.

## Yayın için temel bilgiler

- Marka adı, resmi firma unvanı ve kısa tanıtım.
- Hizmet verilen bölgeler ve hizmetler.
- Doğrulanmış telefon, WhatsApp, e-posta, adres ve çalışma saatleri.
- Logo; mümkünse SVG veya şeffaf PNG. Varsa marka renkleri.
- Yayınlanacak ofis/ekip fotoğrafları ve kullanım izinleri.
- Varsa yayınlanacak yetki/belge bilgileri; danışman isim ve görevleri.
- İçerik ve yayın için son onayı verecek kişi.

## Her gerçek portföy için

- Başlık, kalıcı ilan numarası, açıklama ve aktif/rezerve/satıldı durumu.
- İl, ilçe, mahalle ve yayınlanması uygun konum bilgisi.
- Fiyat, para birimi, alan ve taşınmaz niteliği.
- Tapu türü; varsa hisse bilgisi.
- Yayınlanması uygun ada/parsel, biliniyorsa imar, yol ve altyapı bilgileri.
- Fotoğraflar ve varsa video; içerik kullanım hakkı.
- Sorumlu danışman, son kontrol tarihi ve bilgilerin dayanağı.
- Konum/parsel bilgisinin hangi ayrıntıda paylaşılacağı.

## Kapsam kararları

- İlanları kim güncelleyecek? Panel kapsamda mı?
- Form gerekli mi? Talepler nereye ulaşacak, kim yanıtlayacak?
- Ek dil, harita hizmeti veya başka entegrasyon var mı?
- Mevcut alan adı, barındırma ve kurumsal e-posta kimin hesabında?
- Analiz/çerez araçları kullanılacak mı? Gerçek veri akışına uygun metinleri kim sağlayacak?
- Bakım, yedekleme ve yenileme sorumlusu kim?

## Paylaşım yöntemi

Dosyalar düzenli bir klasörde, ilan başına ayrı klasörle paylaşılır. Hesap erişimleri davet yoluyla verilir. Şifre, kimlik veya tapu belgesinin tamamı bu içerik listesi için istenmez. Yayınlanacak bilgiler müşteri tarafından son kez onaylanır.
